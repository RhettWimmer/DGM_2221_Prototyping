using UnityEngine;
using UnityEditor;
using System.Collections;
using ProBuilder2.Common;
using ProBuilder2.EditorCommon;

namespace ProBuilder2.Actions
{
	/**
	 *	See MenuActions/Export/ExportAsset.cs
	 */
	[System.Obsolete]
	public class pb_MakeMeshAsset : Editor {}
}
